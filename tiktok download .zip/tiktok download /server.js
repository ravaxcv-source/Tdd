const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname)));

/* ============================================================
   API RESOLVER — adapter untuk downloader API.
   Ganti provider? Cukup ubah fungsi ini.
   Saat ini: TikWM (https://www.tikwm.com/api)
   ============================================================ */
const API_BASE = "https://www.tikwm.com/api/";

async function resolveVideo(tiktokUrl) {
  const endpoint = `${API_BASE}?url=${encodeURIComponent(tiktokUrl)}&hd=1`;
  const res = await fetch(endpoint, {
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error("upstream_http_" + res.status);

  const json = await res.json();
  if (json.code !== 0 || !json.data || (!json.data.play && !json.data.hdplay)) {
    throw new Error(json.code === -1 ? "video_not_found" : "upstream_error");
  }

  const d = json.data;
  return {
    id: d.id || null,
    title: (d.title || "").trim(),
    cover: d.cover || null,
    author: d.author
      ? {
          nickname: d.author.nickname || null,
          username: d.author.unique_id || null,
          avatar: d.author.avatar || null,
        }
      : null,
    duration: d.duration != null ? Number(d.duration) : null,
    size: d.size != null ? Number(d.size) : null,
    hdSize: d.hd_size != null ? Number(d.hd_size) : null,
    videoUrl: d.hdplay || d.play,
    sdVideoUrl: d.play || null,
    musicUrl: d.music || null,
  };
}

/* ============================================================
   POST /api/fetch  — validasi + ambil metadata
   ============================================================ */
const TIKTOK_REGEX =
  /^(https?:\/\/)?((www|m|vm|vt)\.)?tiktok\.com\/[^\s]+$/i;

app.post("/api/fetch", async (req, res) => {
  const url = (req.body?.url || "").trim();

  if (!url || !TIKTOK_REGEX.test(url)) {
    return res.status(400).json({ error: "invalid_url" });
  }

  try {
    const data = await resolveVideo(url);
    res.json({ ok: true, data });
  } catch (err) {
    if (err.message === "video_not_found") {
      return res.status(404).json({ error: "video_not_found" });
    }
    console.error("[fetch error]", err.message);
    res.status(502).json({ error: "fetch_failed" });
  }
});

/* ============================================================
   GET /api/download?src=<url>&name=<filename>
   — Proxy stream dengan header attachment → masuk ke
     Chrome Downloads, bukan tab baru.
   ============================================================ */
app.get("/api/download", async (req, res) => {
  const src = req.query.src;
  let name = (req.query.name || "tiktok-video").toString();

  // Validasi: hanya izinkan URL video dari provider yang dikenal
  try {
    const u = new URL(src);
    const allowedHosts = ["tikwm.com", "www.tikwm.com"];
    if (!allowedHosts.includes(u.hostname)) {
      return res.status(400).json({ error: "invalid_src" });
    }
  } catch {
    return res.status(400).json({ error: "invalid_src" });
  }

  // Sanitasi nama file (buang karakter ilegal)
  name = name
    .replace(/[<>:"/\\|?*-]/g, "")
    .replace(/\s+/g, "-")
    .slice(0, 120);
  if (!name.toLowerCase().endsWith(".mp4") && !name.toLowerCase().endsWith(".mp3")) {
    name += ".mp4";
  }

  try {
    const upstream = await fetch(src, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        Referer: "https://www.tikwm.com/",
      },
      signal: AbortSignal.timeout(60000),
    });

    if (!upstream.ok || !upstream.body) {
      throw new Error("upstream_" + upstream.status);
    }

    const contentType =
      upstream.headers.get("content-type") || "application/octet-stream";
    const contentLength = upstream.headers.get("content-length");

    res.setHeader("Content-Type", contentType);
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${name}"; filename*=UTF-8''${encodeURIComponent(name)}`
    );
    if (contentLength) res.setHeader("Content-Length", contentLength);
    // Izinkan jika frontend & backend di-host terpisah
    res.setHeader("Access-Control-Allow-Origin", "*");

    const { Readable } = require("stream");
    Readable.fromWeb(upstream.body).pipe(res);
  } catch (err) {
    console.error("[download error]", err.message);
    if (!res.headersSent) {
      res.status(502).json({ error: "download_failed" });
    } else {
      res.end();
    }
  }
});

app.listen(PORT, () => {
  console.log(`TTD Downloader running at http://localhost:${PORT}`);
});
