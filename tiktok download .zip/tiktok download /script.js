/* ============================================================
   TTD DOWNLOADER — Frontend Logic
   Alur: URL → validasi → POST /api/fetch → tampil hasil
         → klik Download → GET /api/download (attachment)
   ============================================================ */

const form = document.getElementById("downloadForm");
const urlInput = document.getElementById("urlInput");
const pasteBtn = document.getElementById("pasteBtn");
const submitBtn = document.getElementById("submitBtn");
const btnLabel = submitBtn.querySelector(".btn__label");
const btnSpinner = submitBtn.querySelector(".btn__spinner");

const statusBar = document.getElementById("statusBar");
const statusText = document.getElementById("statusText");

const errorBox = document.getElementById("errorBox");
const errorText = document.getElementById("errorText");

const resultCard = document.getElementById("resultCard");
const resultThumb = document.getElementById("resultThumb");
const resultDuration = document.getElementById("resultDuration");
const resultAuthor = document.getElementById("resultAuthor");
const resultTitle = document.getElementById("resultTitle");
const resultSize = document.getElementById("resultSize");
const dlVideoBtn = document.getElementById("dlVideoBtn");
const dlMp3Btn = document.getElementById("dlMp3Btn");
const dlStarted = document.getElementById("dlStarted");

const TIKTOK_REGEX = /^(https?:\/\/)?((www|m|vm|vt)\.)?tiktok\.com\/[^\s]+$/i;

let currentData = null;

/* ---------- Helpers UI ---------- */
function setLoading(isLoading, text) {
  submitBtn.disabled = isLoading;
  btnLabel.textContent = isLoading ? "Memproses..." : "Download";
  btnSpinner.hidden = !isLoading;

  if (isLoading) {
    statusBar.hidden = false;
    statusText.textContent = text || "Mengambil video...";
    errorBox.hidden = true;
    resultCard.hidden = true;
    dlStarted.hidden = true;
  } else {
    statusBar.hidden = true;
  }
}

function showError(msg) {
  statusBar.hidden = true;
  errorText.textContent = msg;
  errorBox.hidden = false;
}

function formatBytes(bytes) {
  if (!bytes || bytes <= 0) return null;
  const mb = bytes / (1024 * 1024);
  return mb.toFixed(1) + " MB";
}

function formatDuration(sec) {
  if (sec == null || isNaN(sec)) return null;
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return m + ":" + String(s).padStart(2, "0");
}

function safeFileName() {
  const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  return "tiktok-video-" + ts;
}

/* ---------- Paste dari clipboard ---------- */
pasteBtn.addEventListener("click", async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (text && text.trim()) {
      urlInput.value = text.trim();
      urlInput.focus();
    }
  } catch {
    // Clipboard API butuh permission — fallback: fokuskan input saja
    urlInput.focus();
  }
});

/* ---------- Submit & Fetch ---------- */
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = urlInput.value.trim();

  // Validasi client-side dulu
  if (!url || !TIKTOK_REGEX.test(url)) {
    showError("Link TikTok tidak valid");
    return;
  }

  setLoading(true, "Mengambil video...");
  currentData = null;

  try {
    const res = await fetch("/api/fetch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });

    const json = await res.json().catch(() => ({}));

    if (!res.ok) {
      if (json.error === "invalid_url") throw new Error("Link TikTok tidak valid");
      if (json.error === "video_not_found") throw new Error("Video tidak ditemukan");
      throw new Error("Gagal mengambil video, coba lagi");
    }

    currentData = json.data;
    renderResult(currentData);
  } catch (err) {
    // Hanya tampilkan pesan ramah, jangan error teknis mentah
    showError(err.message || "Gagal mengambil video, coba lagi");
  } finally {
    setLoading(false);
  }
});

/* ---------- Render hasil ---------- */
function renderResult(data) {
  resultCard.hidden = true;
  dlStarted.hidden = true;

  if (data.cover) {
    resultThumb.src = data.cover;
    resultThumb.alt = "Thumbnail video";
  } else {
    resultThumb.removeAttribute("src");
    resultThumb.alt = "Thumbnail tidak tersedia";
  }

  const dur = formatDuration(data.duration);
  if (dur) {
    resultDuration.textContent = dur;
    resultDuration.hidden = false;
  } else {
    resultDuration.hidden = true;
  }

  resultAuthor.textContent = data.author?.username
    ? data.author.username + (data.author.nickname ? " (" + data.author.nickname + ")" : "")
    : "Kreator TikTok";

  resultTitle.textContent = data.title || "Video TikTok";

  const size = formatBytes(data.hdSize || data.size);
  if (size) {
    resultSize.textContent = size;
    resultSize.hidden = false;
  } else {
    resultSize.hidden = true;
  }

  dlMp3Btn.hidden = !data.musicUrl;

  setLoading(true, "Video siap didownload");
  setTimeout(() => {
    setLoading(false);
    resultCard.hidden = false;
    resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, 500);
}

/* ---------- Download via endpoint proxy (attachment) ----------
   <a href="/api/download?..."> dengan response Content-Disposition:
   attachment → browser memulai download ke folder Downloads.
   Bukan window.open, bukan tab baru. */
function triggerDownload(src, filename) {
  const a = document.createElement("a");
  a.href = "/api/download?src=" + encodeURIComponent(src) + "&name=" + encodeURIComponent(filename);
  a.download = filename; // hint nama file; header attachment yang menentukan
  document.body.appendChild(a);
  a.click();
  a.remove();

  dlStarted.hidden = false;
}

dlVideoBtn.addEventListener("click", () => {
  if (!currentData?.videoUrl) return;
  triggerDownload(currentData.videoUrl, safeFileName() + ".mp4");
});

dlMp3Btn.addEventListener("click", () => {
  if (!currentData?.musicUrl) return;
  triggerDownload(currentData.musicUrl, safeFileName() + ".mp3");
});
